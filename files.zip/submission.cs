using System;
using System.Xml.Schema;
using System.Xml;
using Newtonsoft.Json;
using System.IO;

/**
 * CSE 445 Assignment 4 - XML Validation and XML-to-JSON Conversion
 * 
 * This program:
 *   Q1.1  NationalParks.xsd  - schema defining the XML structure
 *   Q1.2  NationalParks.xml  - valid XML instance with 11 national parks
 *   Q1.3  NationalParksErrors.xml - copy with 5 injected errors
 *   Q2.1  Verification()     - validates an XML file against an XSD schema
 *   Q2.2  Xml2Json()         - converts a valid XML file to JSON
 *   Q3    Main()             - calls all three operations and prints results
 **/

namespace ConsoleApp1
{
    public class Submission
    {
        // Q1.2 - valid XML file hosted on GitHub Pages
        public static string xmlURL = "https://YOUR_GITHUB_USERNAME.github.io/cse445_a4/NationalParks.xml";

        // Q1.3 - error XML file hosted on GitHub Pages
        public static string xmlErrorURL = "https://YOUR_GITHUB_USERNAME.github.io/cse445_a4/NationalParksErrors.xml";

        // Q1.1 - XSD schema file hosted on GitHub Pages
        public static string xsdURL = "https://YOUR_GITHUB_USERNAME.github.io/cse445_a4/NationalParks.xsd";


        // Q3: Main calls all three required operations
        public static void Main(string[] args)
        {
            // Q3 Step 1: Verify valid XML - should print "No errors are found"
            string result = Verification(xmlURL, xsdURL);
            Console.WriteLine(result);

            // Q3 Step 2: Verify error XML - should print error messages
            result = Verification(xmlErrorURL, xsdURL);
            Console.WriteLine(result);

            // Q3 Step 3: Convert valid XML to JSON and print
            result = Xml2Json(xmlURL);
            Console.WriteLine(result);
        }


        // Q2.1 - Validates xmlUrl against xsdUrl.
        // Returns "No errors are found" if valid; otherwise returns the error message.
        public static string Verification(string xmlUrl, string xsdUrl)
        {
            // Accumulate all validation error/warning messages
            string errorMessage = "";

            try
            {
                // Download the XSD content and create a schema set
                string xsdContent = DownloadContent(xsdUrl);
                XmlSchemaSet schemaSet = new XmlSchemaSet();

                // Load schema from the downloaded string
                using (StringReader sr = new StringReader(xsdContent))
                using (XmlReader xsdReader = XmlReader.Create(sr))
                {
                    schemaSet.Add(null, xsdReader);
                }

                // Configure XML reader settings to validate against the schema
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.ValidationType = ValidationType.Schema;
                settings.Schemas = schemaSet;

                // Collect both errors and warnings
                settings.ValidationEventHandler += (sender, e) =>
                {
                    errorMessage += e.Message + "\n";
                };

                // Download the XML and validate it
                string xmlContent = DownloadContent(xmlUrl);
                using (StringReader sr = new StringReader(xmlContent))
                using (XmlReader xmlReader = XmlReader.Create(sr, settings))
                {
                    // Read through the entire document to trigger validation
                    while (xmlReader.Read()) { }
                }
            }
            catch (XmlException ex)
            {
                // Catches well-formedness errors (e.g., missing closing tags)
                errorMessage += ex.Message + "\n";
            }
            catch (Exception ex)
            {
                errorMessage += ex.Message + "\n";
            }

            // Return success message or the accumulated error messages
            if (string.IsNullOrEmpty(errorMessage))
                return "No errors are found";
            else
                return errorMessage.TrimEnd();
        }


        // Q2.2 - Downloads the XML at xmlUrl and converts it to a JSON string.
        // The returned JSON is de-serializable by JsonConvert.DeserializeXmlNode().
        public static string Xml2Json(string xmlUrl)
        {
            string jsonText = "";

            try
            {
                // Download the XML content
                string xmlContent = DownloadContent(xmlUrl);

                // Load into XmlDocument (required for Newtonsoft SerializeXmlNode)
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(xmlContent);

                // Convert to indented JSON using Newtonsoft.Json
                jsonText = JsonConvert.SerializeXmlNode(xmlDoc, Newtonsoft.Json.Formatting.Indented);
            }
            catch (Exception ex)
            {
                jsonText = "Error during XML to JSON conversion: " + ex.Message;
            }

            return jsonText;
        }


        // Helper method: downloads the text content from a URL using WebClient
        private static string DownloadContent(string url)
        {
            using (System.Net.WebClient client = new System.Net.WebClient())
            {
                return client.DownloadString(url);
            }
        }
    }
}
